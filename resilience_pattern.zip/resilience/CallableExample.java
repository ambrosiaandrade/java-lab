package com.pingidentity.adapter.idp.resilience;

import java.util.concurrent.Callable;

public class CallableExample {
    public static void main(String[] args) throws Exception {
        // Cria um Callable que retorna uma String
        Callable<String> tarefa = () -> {
            // Simula algum processamento
            if (Math.random() < 0.5) {
                throw new Exception("Falha simulada");
            }
            return "Sucesso!";
        };

        // Executa o Callable diretamente (normalmente seria usado com ExecutorService)
        try {
            String resultado = tarefa.call();
            System.out.println("Resultado: " + resultado);
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
