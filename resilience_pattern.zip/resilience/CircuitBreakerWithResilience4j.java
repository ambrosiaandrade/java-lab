package com.pingidentity.adapter.idp.resilience;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;

import java.time.Duration;
import java.util.function.Supplier;

public class CircuitBreakerWithResilience4j {
    public static void main(String[] args) {
        // Configure the circuit breaker
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
                .failureRateThreshold(50) // % of failures before opening
                .waitDurationInOpenState(Duration.ofSeconds(5)) // time to stay open
                .slidingWindowSize(4) // number of calls to consider
                .build();

        // Create a registry and circuit breaker
        CircuitBreakerRegistry registry = CircuitBreakerRegistry.of(config);
        CircuitBreaker circuitBreaker = registry.circuitBreaker("myService");

        // Protected operation (simulated)
        Supplier<String> riskySupplier = CircuitBreaker.decorateSupplier(circuitBreaker, () -> {
            if (Math.random() < 0.7) throw new RuntimeException("Simulated failure");
            return "Success";
        });

        // Fallback logic
        Supplier<String> fallback = () -> "Fallback response";

        // Try calling the protected operation several times
        for (int i = 0; i < 10; i++) {
            try {
                String result = riskySupplier.get();
                System.out.println("Attempt " + (i+1) + ": " + result);
            } catch (Exception e) {
                // If circuit is open, fallback
                if (circuitBreaker.getState() == CircuitBreaker.State.OPEN) {
                    System.out.println("Attempt " + (i+1) + ": " + fallback.get() + " (circuit open)");
                } else {
                    System.out.println("Attempt " + (i+1) + ": " + e.getMessage());
                }
            }
        }
    }
}
