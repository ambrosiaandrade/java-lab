package com.pingidentity.adapter.idp.resilience;

import java.util.concurrent.Callable;

/**
 * Simple Retry pattern implementation.
 * Retries a protected operation up to maxAttempts, with delay between attempts.
 */
public class Retry {
    private final int maxAttempts;
    private final long delayMillis;

    /**
     * Constructor to set max attempts and delay between retries.
     * @param maxAttempts Maximum number of attempts
     * @param delayMillis Delay between attempts in milliseconds
     */
    public Retry(int maxAttempts, long delayMillis) {
        this.maxAttempts = maxAttempts;
        this.delayMillis = delayMillis;
    }

    /**
     * Executes the protected operation, retrying on failure.
     * @param action The operation to execute
     * @param <T> Return type
     * @return Result of the operation
     * @throws Exception if all attempts fail
     */
    public <T> T execute(Callable<T> action) throws Exception {
        Exception lastException = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                // Try the protected operation
                return action.call();
            } catch (Exception e) {
                lastException = e;
                // If not last attempt, wait before retrying
                if (attempt < maxAttempts) {
                    Thread.sleep(delayMillis);
                }
            }
        }
        // All attempts failed, throw last exception
        throw lastException;
    }
}
