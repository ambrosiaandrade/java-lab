package com.pingidentity.adapter.idp.resilience;

import java.util.concurrent.Callable;

/**
 * Simple Fallback pattern implementation.
 * Tries the protected operation, returns fallback if it fails.
 */
public class Fallback {
    /**
     * Executes the protected operation, returns fallback if it fails.
     * @param action The operation to execute
     * @param fallback The fallback operation
     * @param <T> Return type
     * @return Result of the operation or fallback
     */
    public <T> T execute(Callable<T> action, Callable<T> fallback) {
        try {
            // Try the protected operation
            return action.call();
        } catch (Exception e) {
            // On failure, return fallback
            return fallback.call();
        }
    }
}
