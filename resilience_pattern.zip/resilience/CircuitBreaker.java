package com.pingidentity.adapter.idp.resilience;

import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;

public class CircuitBreaker {
    // Circuit Breaker states
    public enum State { CLOSED, OPEN, HALF_OPEN }

    // Current state of the circuit breaker
    private State state = State.CLOSED;
    // Number of failures before opening the circuit
    private final int failureThreshold;
    // Number of successful calls in HALF_OPEN before closing the circuit
    private final int successThreshold;
    // How long to stay OPEN before trying again (in milliseconds)
    private final long openTimeoutMillis;
    // Tracks consecutive failures
    private AtomicInteger failureCount = new AtomicInteger(0);
    // Tracks consecutive successes in HALF_OPEN state
    private AtomicInteger successCount = new AtomicInteger(0);
    // Timestamp of last failure (used for OPEN timeout)
    private long lastFailureTime = 0;

    // Constructor to set thresholds and timeout
    public CircuitBreaker(int failureThreshold, int successThreshold, long openTimeoutMillis) {
        this.failureThreshold = failureThreshold;
        this.successThreshold = successThreshold;
        this.openTimeoutMillis = openTimeoutMillis;
    }

    /**
     * Executes the protected action with circuit breaker logic.
     * If the circuit is OPEN, returns fallback immediately.
     * If HALF_OPEN, allows limited test calls to see if service has recovered.
     * If CLOSED, executes normally and tracks failures.
     * @param action The protected operation
     * @param fallback The fallback operation if circuit is OPEN or action fails
     * @return result of action or fallback
     * @throws Exception if action fails and fallback is not used
     */
    public synchronized <T> T execute(Callable<T> action, Callable<T> fallback) throws Exception {
        switch (state) {
            case OPEN:
                // If enough time has passed, try HALF_OPEN state
                if (System.currentTimeMillis() - lastFailureTime > openTimeoutMillis) {
                    state = State.HALF_OPEN;
                } else {
                    // Circuit is OPEN, return fallback immediately
                    return fallback.call();
                }
                // fall through to HALF_OPEN
            case HALF_OPEN:
                try {
                    // Try the protected action
                    T result = action.call();
                    int successes = successCount.incrementAndGet();
                    // If enough successes, close the circuit
                    if (successes >= successThreshold) {
                        state = State.CLOSED;
                        successCount.set(0);
                        failureCount.set(0);
                    }
                    return result;
                } catch (Exception e) {
                    // On failure, re-open the circuit
                    state = State.OPEN;
                    lastFailureTime = System.currentTimeMillis();
                    successCount.set(0);
                    return fallback.call();
                }
            case CLOSED:
            default:
                try {
                    // Try the protected action
                    T result = action.call();
                    // Reset failure count on success
                    failureCount.set(0);
                    return result;
                } catch (Exception e) {
                    // Increment failure count
                    int failures = failureCount.incrementAndGet();
                    // If failures exceed threshold, open the circuit
                    if (failures >= failureThreshold) {
                        state = State.OPEN;
                        lastFailureTime = System.currentTimeMillis();
                    }
                    throw e;
                }
        }
    }

    // Returns the current state of the circuit breaker
    public State getState() {
        return state;
    }
}
