package com.pingidentity.adapter.idp.resilience;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.vavr.control.Try;

import java.time.Duration;
import java.util.function.Supplier;

/**
 * Example usage of Fallback with Resilience4j.
 * Uses Try to provide fallback when the protected operation fails.
 */
public class FallbackWithResilience4j {
    public static void main(String[] args) {
        // Configure a circuit breaker (for demonstration)
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
                .failureRateThreshold(50)
                .waitDurationInOpenState(Duration.ofSeconds(2))
                .slidingWindowSize(4)
                .build();
        CircuitBreakerRegistry registry = CircuitBreakerRegistry.of(config);
        CircuitBreaker circuitBreaker = registry.circuitBreaker("myService");

        // Protected operation (simulated)
        Supplier<String> riskySupplier = CircuitBreaker.decorateSupplier(circuitBreaker, () -> {
            if (Math.random() < 0.7) throw new RuntimeException("Simulated failure");
            return "Success";
        });

        // Fallback logic
        Supplier<String> fallback = () -> "Fallback response";

        // Use Try to execute with fallback
        String result = Try.ofSupplier(riskySupplier)
                .recover(throwable -> fallback.get())
                .get();

        System.out.println("Result: " + result);
    }
}
