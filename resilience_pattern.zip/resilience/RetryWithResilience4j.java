package com.pingidentity.adapter.idp.resilience;

import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;

import java.time.Duration;
import java.util.function.Supplier;

/**
 * Example usage of Resilience4j Retry pattern.
 * Configures a retry policy and decorates a protected operation.
 */
public class RetryWithResilience4j {
    public static void main(String[] args) {
        // Configure the retry: max 3 attempts, 1s wait between attempts
        RetryConfig config = RetryConfig.custom()
                .maxAttempts(3)
                .waitDuration(Duration.ofSeconds(1))
                .build();

        // Create a registry and retry instance
        RetryRegistry registry = RetryRegistry.of(config);
        Retry retry = registry.retry("myService");

        // Protected operation (simulated)
        Supplier<String> riskySupplier = Retry.decorateSupplier(retry, () -> {
            if (Math.random() < 0.7) throw new RuntimeException("Simulated failure");
            return "Success";
        });

        // Fallback logic
        Supplier<String> fallback = () -> "Fallback response";

        // Try calling the protected operation
        try {
            String result = riskySupplier.get();
            System.out.println("Result: " + result);
        } catch (Exception e) {
            System.out.println("All retries failed: " + fallback.get());
        }
    }
}
